import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newitem',
  templateUrl: './newitem.component.html',
  styleUrls: ['./newitem.component.css']
})
export class NewitemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
